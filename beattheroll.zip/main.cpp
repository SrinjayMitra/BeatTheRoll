
#include <iostream>
#include <cstdlib>
#include <time.h>
#include<iomanip>
#include<ios>

using namespace std;

string welcome(){
cout<<"********************************************\nWelcome to Roller's Un-Random house of dice!\n********************************************\n";
return "";
}
string username(){
    string name;
    cout<<"What is your first name? ";
    cin>>name;
    return name;
}
int seed(){
    int random;
    cout<<"Would you like to pick an un-random game, or let the timer pick?\nEnter 0 for timer, or pick your own un-random game: ";
    cin>>random;
    if(random==0){
        cout<<endl<<"THE TIMER! A daring choice!"<<endl;
        srand(time(0));
        
    }
    else{
        cout<<endl<<random<<"! A wise and safe choice."<<endl;
        srand(random);
    }
    return 0;
    // int lb =1 ,ub =6;
    //     srand(time(0));
    // int s=(rand() % (ub - lb + 1)) + lb;
    // return s;
}
int roll(){
    int lb =1 ,ub =6;
        int s=(rand() % (ub - lb + 1)) + lb ;
        return s ;
}
int maxbet(){
    int max;
    cout<<"What would you like to be the maximum bet? :";
    cin>>max;
    while(max<1){
        cout<<"The maximum bet must be greater than or equal to 1."<<endl;
        cout<<"What would you like to be the maximum bet? : ";
        cin>>max;
    }
    return max;
}
int userbet(int maxbet,int score){
    int userbet;
    cout<<"Enter your bet: ";
    cin>>userbet;
    while(userbet<1){
        cout<<"Your must bet at least 1."<<endl;
            cout<<"Enter your bet: ";
    cin>>userbet;
        
    }
    while(userbet>score){
           cout<<"Your must not bet more than your score "<<"("<<score<<")"<<endl;
        
            cout<<"Enter your bet: ";
    cin>>userbet;
        
    }
    while(userbet>maxbet){
            cout<<"Your must not bet more than the maximum bet "<<"("<<maxbet<<")"<<endl;
        
            cout<<"Enter your bet: ";
    cin>>userbet;
        
    }
    return userbet;
    
}


int main()
{
    int  score=50,user=0,i=1,check=0,num,sumofdealer,sumofuser,bet,n,m;
    welcome();
    cout<<endl;
    string name= username();
    cout<<endl;
   int max=maxbet();
   cout<<endl;
   seed();
   
   while(check==0){
       cout<<endl;
        n=0,m=0;
      cout<<"Round "<<i<<" you have "<<score<<"points"<<endl;
     
      cout<<"Dealer rolls: ";
     //dealer rolls 
     sumofdealer=0;
      while(n<2){
          int roll1=roll();
          cout<<roll1;
          sumofdealer+=roll1;
          n+=1;
          if(n<=1){
          cout<<" + ";
          }
         if(n>=2){
               cout<<" =  "<<sumofdealer<<"         ";
            }
        }
        
           bet=userbet(max,score);
           //user roll
           sumofuser=0;
           cout<<"You roll:     ";
           
         while(m<2){
             int roll2=roll();
          cout<<roll2;
          sumofuser+=roll2;
          m+=1;
          if(m<=1){
          cout<<" + ";
          }
         if(m>=2){
               cout<<" =  "<<sumofuser;
                 }
        }
        cout<<endl;
         if(sumofuser>sumofdealer){
             score+=bet;
             cout<<name<<", you won! :-)"<<endl<<"Current score: "<<score<<"."<<endl;
              if(score<=0){
             cout<<endl<<"I'm sorry, "<<name<<" you are out of points so you lose"<<endl;
             check++;
              }
             else if(score>=100){
             cout<<endl<<"Congratulations "<<name<<"! You win the game with a score of "<<score<<"."<<endl;
             check++;
         }
         }  
         else if(sumofuser<sumofdealer){
             score-=bet;
             cout<<name<<", you lost. :-("<<endl<<"Current score: "<<score<<"."<<endl;
              if(score<=0){
             cout<<endl<<"I'm sorry, "<<name<<" you are out of points so you lose"<<endl;
             check++;
              }
             else if(score>=100){
             cout<<endl<<"Congratulations "<<name<<"! You win the game with a score of "<<score<<"."<<endl;
             check++;
         }
         }
         else if(sumofdealer==sumofuser){
             cout<<name<<", you tied. :-("<<endl<<"Current score: "<<score<<"."<<endl;;
              if(score<=0){
             cout<<endl<<"I'm sorry, "<<name<<" you are out of points so you lose"<<endl;
             check++;
             }
             else if(score>=100){
             cout<<endl<<"Congratulations "<<name<<"! You win the game with a score of "<<score<<"."<<endl;
             check++;
         }
         }
         
         
         i++;   
      
   }
    return 0;
}
